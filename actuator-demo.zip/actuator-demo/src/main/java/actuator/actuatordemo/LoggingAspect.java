package actuator.actuatordemo;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {

    private static Logger logger = LoggerFactory.getLogger(HelloWorldController.class);

    @AfterThrowing(pointcut = "execution(* actuator.actuatordemo.HelloWorldController.*(..))",
            throwing = "error")
    public void afterThrowingAdvice(JoinPoint jp, Throwable error){
        System.out.println("*** Method Signature: "  + jp.getSignature());
        System.out.println("*** Exception: "+error);
    }

//@Around("@annotation(org.springframework.web.bind.annotation.GetMapping) && execution(public * *(..))")
@Pointcut("@annotation(org.springframework.web.bind.annotation.GetMapping)")
    public void restControllerMethods() {};
//
    @Before("restControllerMethods()")
    public void logMethodCallController(JoinPoint jp) {
        String methodName = jp.getSignature().getName();
        logger.info("*** Aspect Before Controller " + methodName);
    }


    ///////
    @Pointcut("within(@org.springframework.stereotype.Controller *)")
    public void controller() {}

    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void restController() {}


    @Around("controller() || restController()")
    public Object validate(ProceedingJoinPoint point) throws Throwable {
        logger.info("*** Aspect Before REst Controller " + point.getSignature().getName());;
        Object result = point.proceed();
        logger.info("*** Aspect After Rest Controller " + point.getSignature().getName());

        return result;
    }

    //
}
